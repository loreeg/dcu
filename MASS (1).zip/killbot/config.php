<?php

$CONFIG_KILLBOT = [
    'active'        => true, // If 'true' will set blocker protection active, and 'false' will deactive protection
    'apikey'        => 'nBkm6dx9DNr19cUXcP54z-4hL66Oc3dUp_4Ny9oNJ-fBn', // Your API Key from https://killbot.org/developer
    'bot_redirect'  => 'https://mail.google.com/' // Bot will be redirect to this URL or you can change with 403, 404, suspend or cloudflare.
];